#!/data/data/com.termux/files/usr/bin/bash
echo "alias -='cd $HOME/- && chmod +x x && ./x'" >> $HOME/.bashrc
echo "快捷命令 '-' 已创建，你可以通过输入-进入工具"
source ~/.bashrc
