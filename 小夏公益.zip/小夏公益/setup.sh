#!/data/data/com.termux/files/usr/bin/bash
echo "alias 小夏公益='cd $HOME/小夏公益 && chmod +x x && ./x'" >> $HOME/.bashrc
echo "快捷命令 '小夏公益' 已创建，你可以通过输入小夏公益进入工具"
source ~/.bashrc
